package calculadora.com.calculadora;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    Button button1,button2,button3,button4,button5,button6,button7,button8,button9,buttondiv,buttonsum,buttonres,buttonmul,buttoneq,buttonac,button0;
    TextView textViewres,textViewop;
    String num2 = "";
    String num1 = "";
    String op = "";
    Double aux;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewres = findViewById(R.id.textView2);
        textViewop = findViewById(R.id.textView);

        button0 = findViewById(R.id.button13);
        button1 = findViewById(R.id.button16);
        button2 = findViewById(R.id.button15);
        button3 = findViewById(R.id.button9);
        button4 = findViewById(R.id.button8);
        button5 = findViewById(R.id.button7);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button4);
        button8 = findViewById(R.id.button3);
        button9 = findViewById(R.id.button2);
        buttondiv = findViewById(R.id.button1);
        buttonac = findViewById(R.id.button14);
        buttoneq = findViewById(R.id.button12);
        buttonres = findViewById(R.id.button11);
        buttonsum = findViewById(R.id.button10);
        buttonmul = findViewById(R.id.button5);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    View.OnClickListener number = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button button = (Button) view;
                if (op.equals("")) {
                    num1 += button.getText().toString();
                    aux = 0.0;
                    textViewop.setText(num1);
                } else {
                    if (!Objects.equals(aux,0.0)) num1 = Double.toString(aux);
                    num2 += button.getText().toString();
                    textViewop.append(button.getText());
                }
            }
        };
        button0.setOnClickListener(number);
        button1.setOnClickListener(number);
        button2.setOnClickListener(number);
        button3.setOnClickListener(number);
        button4.setOnClickListener(number);
        button5.setOnClickListener(number);
        button6.setOnClickListener(number);
        button7.setOnClickListener(number);
        button8.setOnClickListener(number);
        button9.setOnClickListener(number);

        View.OnClickListener number2 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button button = (Button) view;
                textViewop.append(" " + button.getText() + " ");
                op = button.getText().toString();
            }
        };
        buttonsum.setOnClickListener(number2);
        buttonres.setOnClickListener(number2);
        buttonmul.setOnClickListener(number2);
        buttondiv.setOnClickListener(number2);


        View.OnClickListener equals = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Button button = (Button) view;
                double result = performOp();
                op = "";
                num1 = "";
                num2 = "";
                textViewres.setText(Double.toString(result));
            }
        };
        buttoneq.setOnClickListener(equals);

        View.OnClickListener reset = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             op = "";
             num1 = "";
             num2 = "";
             textViewres.setText("0");
             textViewop.setText("");
            }
        };
        buttonac.setOnClickListener(reset);
    }
    double performOp() {
        double d1 = Double.parseDouble(this.num1);
        double d2 = Double.parseDouble(this.num2);
        double d;
        if (Objects.equals(op, "+")){
            d = d1 + d2;
        }
        else if (Objects.equals(op, "-")){
            d = d1 - d2;
        }
        else if (Objects.equals(op, "/")){
            d = d1 / d2;
        }
        else {
            d = d1*d2;
        }
        aux = d;
        return d;
    }
    @Override
    protected void onSaveInstanceState(Bundle outstate){
        super.onSaveInstanceState(outstate);
        outstate.putString("op", textViewop.getText().toString());
        outstate.putString("result", textViewres.getText().toString());
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        TextView t = (TextView) findViewById(R.id.textView);
        TextView t2 = (TextView) findViewById(R.id.textView2);
        textViewop.setText(savedInstanceState.getString("op"));
        textViewres.setText(savedInstanceState.getString("result"));

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainmenu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.option1:
                callmymum();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    void callmymum() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:999999999"));
        startActivity(intent);
    }
    }