package calculadora.com.calculadora;

import java.util.Objects;

public class User {
   protected static String name = "marc";
   protected static String pass = "contraseñasegura";
   public static boolean logIn(String n, String p) {
        if (Objects.equals(name,n) ){
           if (Objects.equals(pass, p)) return true;
       }
        return false;
    }
}
