package calculadora.com.calculadora;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class log_activity extends AppCompatActivity {
    TextInputLayout us,ps;
    Button b;
    TextView valid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_activity);

        us = findViewById(R.id.user);
        ps = findViewById(R.id.password);
        b = findViewById(R.id.buttonsign);
        valid = findViewById(R.id.textViewlog);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tryname = us.getEditText().getText().toString().trim();
                String trypass = ps.getEditText().getText().toString().trim();

                if (User.logIn(tryname,trypass)) {
                    valid.setText(R.string.loginsuccess);
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                }
                else {
                    valid.setText(R.string.loginfailed);
                }
            }
        });
    }
}
